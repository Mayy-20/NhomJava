package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "chude")
@Data
public class ChuDe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maChuDe;

    @Column(nullable = false, unique = true)
    private String tenChuDe;

    private String moTa;
}