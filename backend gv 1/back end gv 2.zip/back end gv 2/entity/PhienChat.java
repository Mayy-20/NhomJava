package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "phienchat")
@Data
public class PhienChat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maPhienChat;

    @ManyToOne
    @JoinColumn(name = "maNguoiDung", nullable = false)
    private NguoiDung nguoiDung;

    @Column(nullable = false)
    private LocalDateTime ngayTao = LocalDateTime.now();
}