package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "binhluan")
@Data
public class BinhLuan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maBinhLuan;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String noiDung;

    @ManyToOne
    @JoinColumn(name = "maBaiDang", nullable = false)
    private BaiDang baiDang;

    @ManyToOne
    @JoinColumn(name = "maNguoiDung", nullable = false)
    private NguoiDung nguoiDung;

    @Column(nullable = false)
    private LocalDateTime ngayBinhLuan = LocalDateTime.now();
}