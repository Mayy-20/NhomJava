package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "tiendo")
@Data
public class TienDo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maTienDo;

    @ManyToOne
    @JoinColumn(name = "maHocVien", nullable = false)
    private NguoiDung hocVien;

    @ManyToOne
    @JoinColumn(name = "maKhoaHoc", nullable = false)
    private KhoaHoc khoaHoc;

    @ManyToOne
    @JoinColumn(name = "maBaiHoc")
    private BaiHoc baiHoc;

    private Integer phanTramHoanThanh;
}