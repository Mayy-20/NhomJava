package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "tinnhan")
@Data
public class TinNhan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maTinNhan;

    @ManyToOne
    @JoinColumn(name = "maPhienChat", nullable = false)
    private PhienChat phienChat;

    @ManyToOne
    @JoinColumn(name = "maNguoiGui", nullable = false)
    private NguoiDung nguoiGui;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String noiDung;

    @Column(nullable = false)
    private LocalDateTime ngayGui = LocalDateTime.now();
}