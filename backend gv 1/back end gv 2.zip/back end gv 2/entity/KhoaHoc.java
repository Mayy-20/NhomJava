package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "khoahoc")
@Data
public class KhoaHoc {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maKhoaHoc;

    @Column(nullable = false, unique = true)
    private String tenKhoaHoc;

    private String moTa;
    private String hinhAnh;
    private Boolean mienPhi = true;

    @Enumerated(EnumType.STRING)
    private TrangThaiKhoaHoc trangThai;

    private Float danhGiaTB = 0.0f;
    private Integer soLuongHocVien = 0;

    @Column(nullable = false)
    private LocalDateTime ngayTao = LocalDateTime.now();

    @ManyToOne
    @JoinColumn(name = "maGiangVien", nullable = false)
    private NguoiDung giangVien;

    @ManyToMany
    @JoinTable(
        name = "khoahoc_chude",
        joinColumns = @JoinColumn(name = "maKhoaHoc"),
        inverseJoinColumns = @JoinColumn(name = "maChuDe")
    )
    private List<ChuDe> chuDes;

    public enum TrangThaiKhoaHoc {
        HoatDong, ChoDuyet, An
    }
}