package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "dangky")
@Data
public class DangKy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maDangKy;

    @ManyToOne
    @JoinColumn(name = "maHocVien", nullable = false)
    private NguoiDung hocVien;

    @ManyToOne
    @JoinColumn(name = "maKhoaHoc", nullable = false)
    private KhoaHoc khoaHoc;

    @Column(nullable = false)
    private LocalDateTime ngayDangKy = LocalDateTime.now();
}