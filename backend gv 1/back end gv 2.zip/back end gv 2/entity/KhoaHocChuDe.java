package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "khoahoc_chude")
@Data
public class KhoaHocChuDe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maKhoaHocChuDe;

    @ManyToOne
    @JoinColumn(name = "maKhoaHoc", nullable = false)
    private KhoaHoc khoaHoc;

    @ManyToOne
    @JoinColumn(name = "maChuDe", nullable = false)
    private ChuDe chuDe;
}