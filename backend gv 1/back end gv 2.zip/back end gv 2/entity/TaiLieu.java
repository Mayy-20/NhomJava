package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "tailieu")
@Data
public class TaiLieu {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maTaiLieu;

    @Column(nullable = false)
    private String tenTaiLieu;

    @Column(nullable = false)
    private String duongDan;

    @ManyToOne
    @JoinColumn(name = "maBaiHoc", nullable = false)
    private BaiHoc baiHoc;

    @ManyToOne
    @JoinColumn(name = "maTacGia", nullable = false)
    private NguoiDung tacGia;

    @ManyToOne
    @JoinColumn(name = "maLoaiTaiLieu", nullable = false)
    private LoaiTaiLieu loaiTaiLieu;

    @Column(nullable = false)
    private LocalDateTime ngayTao = LocalDateTime.now();
}