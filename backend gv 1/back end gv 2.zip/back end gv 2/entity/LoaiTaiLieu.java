package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "loaitailieu")
@Data
public class LoaiTaiLieu {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maLoaiTaiLieu;

    @Column(nullable = false, unique = true)
    private String tenLoai;
}