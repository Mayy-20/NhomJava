package com.hannah.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Table(name = "baidang")
@Data
public class BaiDang {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer maBaiDang;

    @Column(nullable = false)
    private String tieuDe;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String noiDung;

    @ManyToOne
    @JoinColumn(name = "maTacGia", nullable = false)
    private NguoiDung tacGia;

    @ManyToOne
    @JoinColumn(name = "maKhoaHoc")
    private KhoaHoc khoaHoc;

    @Column(nullable = false)
    private LocalDateTime ngayDang = LocalDateTime.now();
}