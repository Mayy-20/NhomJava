package com.hannah.controller;

import com.hannah.dto.BaiHocDTO;
import com.hannah.service.BaiHocService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/baihoc")
public class BaiHocController {

    @Autowired
    private BaiHocService baiHocService;

    @PostMapping
    public ResponseEntity<BaiHocDTO> createBaiHoc(@RequestBody BaiHocDTO baiHocDTO, @RequestParam Integer maKhoaHoc) {
        return ResponseEntity.ok(baiHocService.createBaiHoc(baiHocDTO, maKhoaHoc));
    }

    @GetMapping("/khoahoc/{maKhoaHoc}")
    public ResponseEntity<List<BaiHocDTO>> getBaiHocByKhoaHoc(@PathVariable Integer maKhoaHoc) {
        return ResponseEntity.ok(baiHocService.getBaiHocByKhoaHoc(maKhoaHoc));
    }

    @PutMapping("/{maBaiHoc}")
    public ResponseEntity<BaiHocDTO> updateBaiHoc(@PathVariable Integer maBaiHoc, @RequestBody BaiHocDTO baiHocDTO) {
        return ResponseEntity.ok(baiHocService.updateBaiHoc(maBaiHoc, baiHocDTO));
    }

    @DeleteMapping("/{maBaiHoc}")
    public ResponseEntity<Void> deleteBaiHoc(@PathVariable Integer maBaiHoc) {
        baiHocService.deleteBaiHoc(maBaiHoc);
        return ResponseEntity.noContent().build();
    }
}