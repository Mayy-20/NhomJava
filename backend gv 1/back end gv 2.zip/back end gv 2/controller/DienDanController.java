package com.hannah.controller;

import com.hannah.dto.DienDanDTO;
import com.hannah.service.DienDanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/diendan")
public class DienDanController {

    @Autowired
    private DienDanService dienDanService;

    @PostMapping
    public ResponseEntity<DienDanDTO> createDienDanPost(@RequestBody DienDanDTO dienDanDTO, @RequestParam Integer maNguoiDung) {
        return ResponseEntity.ok(dienDanService.createDienDanPost(dienDanDTO, maNguoiDung));
    }

    @GetMapping("/khoahoc/{maKhoaHoc}")
    public ResponseEntity<List<DienDanDTO>> getDienDanByKhoaHoc(@PathVariable Integer maKhoaHoc) {
        return ResponseEntity.ok(dienDanService.getDienDanByKhoaHoc(maKhoaHoc));
    }

    @DeleteMapping("/{maDienDan}")
    public ResponseEntity<Void> deleteDienDanPost(@PathVariable Integer maDienDan) {
        dienDanService.deleteDienDanPost(maDienDan);
        return ResponseEntity.noContent().build();
    }
}