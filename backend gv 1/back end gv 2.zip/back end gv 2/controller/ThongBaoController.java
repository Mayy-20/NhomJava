package com.hannah.controller;

import com.hannah.dto.ThongBaoDTO;
import com.hannah.service.ThongBaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/thongbao")
public class ThongBaoController {

    @Autowired
    private ThongBaoService thongBaoService;

    @PostMapping
    public ResponseEntity<ThongBaoDTO> createThongBao(@RequestBody ThongBaoDTO thongBaoDTO, @RequestParam Integer maNguoiGui) {
        return ResponseEntity.ok(thongBaoService.createThongBao(thongBaoDTO, maNguoiGui));
    }

    @GetMapping("/nguoigui/{maNguoiGui}")
    public ResponseEntity<List<ThongBaoDTO>> getThongBaoByNguoiGui(@PathVariable Integer maNguoiGui) {
        return ResponseEntity.ok(thongBaoService.getThongBaoByNguoiGui(maNguoiGui));
    }

    @DeleteMapping("/{maThongBao}")
    public ResponseEntity<Void> deleteThongBao(@PathVariable Integer maThongBao) {
        thongBaoService.deleteThongBao(maThongBao);
        return ResponseEntity.noContent().build();
    }
}