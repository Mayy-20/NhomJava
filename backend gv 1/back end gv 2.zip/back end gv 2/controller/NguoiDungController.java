package com.hannah.controller;

import com.hannah.dto.NguoiDungDTO;
import com.hannah.service.NguoiDungService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/nguoidung")
public class NguoiDungController {

    @Autowired
    private NguoiDungService nguoiDungService;

    @GetMapping("/{maNguoiDung}")
    public ResponseEntity<NguoiDungDTO> getNguoiDungById(@PathVariable Integer maNguoiDung) {
        return ResponseEntity.ok(nguoiDungService.getNguoiDungById(maNguoiDung));
    }

    @PutMapping("/{maNguoiDung}")
    public ResponseEntity<NguoiDungDTO> updateNguoiDung(@PathVariable Integer maNguoiDung, @RequestBody NguoiDungDTO nguoiDungDTO) {
        return ResponseEntity.ok(nguoiDungService.updateNguoiDung(maNguoiDung, nguoiDungDTO));
    }

    @PutMapping("/{maNguoiDung}/settings")
    public ResponseEntity<NguoiDungDTO> updateSettings(@PathVariable Integer maNguoiDung, @RequestBody NguoiDungDTO settingsDTO) {
        return ResponseEntity.ok(nguoiDungService.updateSettings(maNguoiDung, settingsDTO));
    }
}