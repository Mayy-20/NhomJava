package com.hannah.controller;

import com.hannah.dto.KhoaHocDTO;
import com.hannah.service.KhoaHocService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/khoahoc")
public class KhoaHocController {

    @Autowired
    private KhoaHocService khoaHocService;

    @PostMapping
    public ResponseEntity<KhoaHocDTO> createKhoaHoc(@RequestBody KhoaHocDTO khoaHocDTO, @RequestParam Integer maGiangVien) {
        return ResponseEntity.ok(khoaHocService.createKhoaHoc(khoaHocDTO, maGiangVien));
    }

    @GetMapping("/giangvien/{maGiangVien}")
    public ResponseEntity<List<KhoaHocDTO>> getKhoaHocByGiangVien(@PathVariable Integer maGiangVien) {
        return ResponseEntity.ok(khoaHocService.getKhoaHocByGiangVien(maGiangVien));
    }

    @GetMapping("/{maKhoaHoc}")
    public ResponseEntity<KhoaHocDTO> getKhoaHocById(@PathVariable Integer maKhoaHoc) {
        return ResponseEntity.ok(khoaHocService.getKhoaHocById(maKhoaHoc));
    }

    @PutMapping("/{maKhoaHoc}")
    public ResponseEntity<KhoaHocDTO> updateKhoaHoc(@PathVariable Integer maKhoaHoc, @RequestBody KhoaHocDTO khoaHocDTO) {
        return ResponseEntity.ok(khoaHocService.updateKhoaHoc(maKhoaHoc, khoaHocDTO));
    }

    @DeleteMapping("/{maKhoaHoc}")
    public ResponseEntity<Void> deleteKhoaHoc(@PathVariable Integer maKhoaHoc) {
        khoaHocService.deleteKhoaHoc(maKhoaHoc);
        return ResponseEntity.noContent().build();
    }
}