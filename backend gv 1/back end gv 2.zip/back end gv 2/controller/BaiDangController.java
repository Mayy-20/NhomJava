package com.hannah.controller;

import com.hannah.dto.BaiDangDTO;
import com.hannah.service.BaiDangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/baidang")
public class BaiDangController {

    @Autowired
    private BaiDangService baiDangService;

    @PostMapping
    public ResponseEntity<BaiDangDTO> createBaiDang(@RequestBody BaiDangDTO baiDangDTO, @RequestParam Integer maTacGia) {
        return ResponseEntity.ok(baiDangService.createBaiDang(baiDangDTO, maTacGia));
    }

    @GetMapping
    public ResponseEntity<List<BaiDangDTO>> getAllBaiDang() {
        return ResponseEntity.ok(baiDangService.getAllBaiDang());
    }

    @PutMapping("/{maBaiDang}")
    public ResponseEntity<BaiDangDTO> updateBaiDang(@PathVariable Integer maBaiDang, @RequestBody BaiDangDTO baiDangDTO) {
        return ResponseEntity.ok(baiDangService.updateBaiDang(maBaiDang, baiDangDTO));
    }

    @DeleteMapping("/{maBaiDang}")
    public ResponseEntity<Void> deleteBaiDang(@PathVariable Integer maBaiDang) {
        baiDangService.deleteBaiDang(maBaiDang);
        return ResponseEntity.noContent().build();
    }
}