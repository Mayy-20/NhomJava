package com.hannah.controller;

import com.hannah.dto.TienDoDTO;
import com.hannah.service.TienDoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tiendo")
public class TienDoController {

    @Autowired
    private TienDoService tienDoService;

    @GetMapping("/hocvien/{maNguoiDung}")
    public ResponseEntity<List<TienDoDTO>> getTienDoByHocVien(@PathVariable Integer maNguoiDung) {
        return ResponseEntity.ok(tienDoService.getTienDoByHocVien(maNguoiDung));
    }

    @GetMapping("/khoahoc/{maKhoaHoc}/hocvien/{maNguoiDung}")
    public ResponseEntity<TienDoDTO> getTienDoByHocVienAndKhoaHoc(@PathVariable Integer maNguoiDung, @PathVariable Integer maKhoaHoc) {
        return ResponseEntity.ok(tienDoService.getTienDoByHocVienAndKhoaHoc(maNguoiDung, maKhoaHoc));
    }

    @PutMapping("/{maTienDo}")
    public ResponseEntity<TienDoDTO> updateTienDo(@PathVariable Integer maTienDo, @RequestBody TienDoDTO tienDoDTO) {
        return ResponseEntity.ok(tienDoService.updateTienDo(maTienDo, tienDoDTO));
    }
}