package com.hannah.controller;

import com.hannah.dto.LoginRequest;
import com.hannah.dto.LoginResponse;
import com.hannah.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        LoginResponse response = authService.login(request.getEmail(), request.getMatKhau());
        return ResponseEntity.ok(response);
    }

    @PostMapping("/register")
    public ResponseEntity<LoginResponse> register(@RequestBody LoginRequest request) {
        LoginResponse response = authService.register(request.getEmail(), request.getMatKhau(), request.getHoTen());
        return ResponseEntity.ok(response);
    }
}