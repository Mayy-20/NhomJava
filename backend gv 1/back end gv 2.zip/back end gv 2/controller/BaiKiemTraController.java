package com.hannah.controller;

import com.hannah.dto.BaiKiemTraDTO;
import com.hannah.service.BaiKiemTraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/baikiemtra")
public class BaiKiemTraController {

    @Autowired
    private BaiKiemTraService baiKiemTraService;

    @PostMapping
    public ResponseEntity<BaiKiemTraDTO> createBaiKiemTra(@RequestBody BaiKiemTraDTO baiKiemTraDTO, @RequestParam Integer maKhoaHoc) {
        return ResponseEntity.ok(baiKiemTraService.createBaiKiemTra(baiKiemTraDTO, maKhoaHoc));
    }

    @GetMapping("/khoahoc/{maKhoaHoc}")
    public ResponseEntity<List<BaiKiemTraDTO>> getBaiKiemTraByKhoaHoc(@PathVariable Integer maKhoaHoc) {
        return ResponseEntity.ok(baiKiemTraService.getBaiKiemTraByKhoaHoc(maKhoaHoc));
    }

    @PutMapping("/{maBaiKiemTra}")
    public ResponseEntity<BaiKiemTraDTO> updateBaiKiemTra(@PathVariable Integer maBaiKiemTra, @RequestBody BaiKiemTraDTO baiKiemTraDTO) {
        return ResponseEntity.ok(baiKiemTraService.updateBaiKiemTra(maBaiKiemTra, baiKiemTraDTO));
    }

    @DeleteMapping("/{maBaiKiemTra}")
    public ResponseEntity<Void> deleteBaiKiemTra(@PathVariable Integer maBaiKiemTra) {
        baiKiemTraService.deleteBaiKiemTra(maBaiKiemTra);
        return ResponseEntity.noContent().build();
    }
}