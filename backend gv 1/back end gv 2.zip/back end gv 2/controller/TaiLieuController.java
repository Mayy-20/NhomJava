package com.hannah.controller;

import com.hannah.dto.TaiLieuDTO;
import com.hannah.service.TaiLieuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/tailieu")
public class TaiLieuController {

    @Autowired
    private TaiLieuService taiLieuService;

    @PostMapping
    public ResponseEntity<TaiLieuDTO> uploadTaiLieu(@RequestParam("file") MultipartFile file, @RequestParam Integer maBaiHoc, @RequestParam Integer maTacGia) {
        return ResponseEntity.ok(taiLieuService.uploadTaiLieu(file, maBaiHoc, maTacGia));
    }

    @GetMapping("/baihoc/{maBaiHoc}")
    public ResponseEntity<List<TaiLieuDTO>> getTaiLieuByBaiHoc(@PathVariable Integer maBaiHoc) {
        return ResponseEntity.ok(taiLieuService.getTaiLieuByBaiHoc(maBaiHoc));
    }

    @DeleteMapping("/{maTaiLieu}")
    public ResponseEntity<Void> deleteTaiLieu(@PathVariable Integer maTaiLieu) {
        taiLieuService.deleteTaiLieu(maTaiLieu);
        return ResponseEntity.noContent().build();
    }
}