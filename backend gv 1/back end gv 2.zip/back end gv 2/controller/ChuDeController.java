package com.hannah.controller;

import com.hannah.dto.ChuDeDTO;
import com.hannah.service.ChuDeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chude")
public class ChuDeController {

    @Autowired
    private ChuDeService chuDeService;

    @PostMapping
    public ResponseEntity<ChuDeDTO> createChuDe(@RequestBody ChuDeDTO chuDeDTO) {
        return ResponseEntity.ok(chuDeService.createChuDe(chuDeDTO));
    }

    @GetMapping
    public ResponseEntity<List<ChuDeDTO>> getAllChuDe() {
        return ResponseEntity.ok(chuDeService.getAllChuDe());
    }

    @PutMapping("/{maChuDe}")
    public ResponseEntity<ChuDeDTO> updateChuDe(@PathVariable Integer maChuDe, @RequestBody ChuDeDTO chuDeDTO) {
        return ResponseEntity.ok(chuDeService.updateChuDe(maChuDe, chuDeDTO));
    }

    @DeleteMapping("/{maChuDe}")
    public ResponseEntity<Void> deleteChuDe(@PathVariable Integer maChuDe) {
        chuDeService.deleteChuDe(maChuDe);
        return ResponseEntity.noContent().build();
    }
}