package com.hannah.controller;

import com.hannah.dto.HocVienDTO;
import com.hannah.service.HocVienService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hocvien")
public class HocVienController {

    @Autowired
    private HocVienService hocVienService;

    @PostMapping
    public ResponseEntity<HocVienDTO> addHocVien(@RequestBody HocVienDTO hocVienDTO) {
        return ResponseEntity.ok(hocVienService.addHocVien(hocVienDTO));
    }

    @GetMapping("/khoahoc/{maKhoaHoc}")
    public ResponseEntity<List<HocVienDTO>> getHocVienByKhoaHoc(@PathVariable Integer maKhoaHoc) {
        return ResponseEntity.ok(hocVienService.getHocVienByKhoaHoc(maKhoaHoc));
    }

    @GetMapping("/{maNguoiDung}")
    public ResponseEntity<HocVienDTO> getHocVienById(@PathVariable Integer maNguoiDung) {
        return ResponseEntity.ok(hocVienService.getHocVienById(maNguoiDung));
    }

    @DeleteMapping("/{maNguoiDung}")
    public ResponseEntity<Void> deleteHocVien(@PathVariable Integer maNguoiDung) {
        hocVienService.deleteHocVien(maNguoiDung);
        return ResponseEntity.noContent().build();
    }
}