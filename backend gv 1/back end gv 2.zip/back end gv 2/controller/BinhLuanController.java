package com.hannah.controller;

import com.hannah.dto.BinhLuanDTO;
import com.hannah.service.BinhLuanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/binhluan")
public class BinhLuanController {

    @Autowired
    private BinhLuanService binhLuanService;

    @PostMapping
    public ResponseEntity<BinhLuanDTO> createBinhLuan(@RequestBody BinhLuanDTO binhLuanDTO, @RequestParam Integer maBaiDang, @RequestParam Integer maNguoiDung) {
        return ResponseEntity.ok(binhLuanService.createBinhLuan(binhLuanDTO, maBaiDang, maNguoiDung));
    }

    @GetMapping("/baidang/{maBaiDang}")
    public ResponseEntity<List<BinhLuanDTO>> getBinhLuanByBaiDang(@PathVariable Integer maBaiDang) {
        return ResponseEntity.ok(binhLuanService.getBinhLuanByBaiDang(maBaiDang));
    }

    @DeleteMapping("/{maBinhLuan}")
    public ResponseEntity<Void> deleteBinhLuan(@PathVariable Integer maBinhLuan) {
        binhLuanService.deleteBinhLuan(maBinhLuan);
        return ResponseEntity.noContent().build();
    }
}