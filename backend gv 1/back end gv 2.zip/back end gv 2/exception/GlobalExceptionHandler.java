package com.hannah.exception;

import com.hannah.util.RestResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<RestResponse<Object>> handleResourceNotFoundException(ResourceNotFoundException ex, WebRequest request) {
        return new ResponseEntity<>(
            RestResponse.error(HttpStatus.NOT_FOUND.value(), ex.getMessage(), request.getDescription(false)),
            HttpStatus.NOT_FOUND
        );
    }

    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<RestResponse<Object>> handleUnauthorizedException(UnauthorizedException ex, WebRequest request) {
        return new ResponseEntity<>(
            RestResponse.error(HttpStatus.UNAUTHORIZED.value(), ex.getMessage(), request.getDescription(false)),
            HttpStatus.UNAUTHORIZED
        );
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<RestResponse<Object>> handleRuntimeException(RuntimeException ex, WebRequest request) {
        return new ResponseEntity<>(
            RestResponse.error(HttpStatus.BAD_REQUEST.value(), ex.getMessage(), request.getDescription(false)),
            HttpStatus.BAD_REQUEST
        );
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<RestResponse<Object>> handleGeneralException(Exception ex, WebRequest request) {
        return new ResponseEntity<>(
            RestResponse.error(HttpStatus.INTERNAL_SERVER_ERROR.value(), "An unexpected error occurred", request.getDescription(false)),
            HttpStatus.INTERNAL_SERVER_ERROR
        );
    }
}