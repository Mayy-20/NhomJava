package com.hannah.dto;

import lombok.Data;

@Data
public class BinhLuanDTO {
    private Integer maBinhLuan;
    private String noiDung;
    private Integer maBaiDang;
    private Integer maNguoiDung;
}