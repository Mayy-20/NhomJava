package com.hannah.dto;

import lombok.Data;

@Data
public class LoginResponse {
    private Integer maNguoiDung;
    private String email;
    private String hoTen;
    private String token;
}