package com.hannah.dto;

import lombok.Data;

@Data
public class NguoiDungDTO {
    private Integer maNguoiDung;
    private String tenDangNhap;
    private String email;
    private String hoTen;
    private String dienThoai;
    private String gioiThieu;
    private String anhDaiDien;
    private String trangThai;
    private String matKhau;
}