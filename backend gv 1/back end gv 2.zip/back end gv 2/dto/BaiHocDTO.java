package com.hannah.dto;

import lombok.Data;

@Data
public class BaiHocDTO {
    private Integer maBaiHoc;
    private String tenBaiHoc;
    private Integer maKhoaHoc;
    private Integer thuTu;
    private String videoURL;
    private String capDo;
    private String thoiLuong;
}