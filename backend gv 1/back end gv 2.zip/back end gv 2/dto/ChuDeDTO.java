package com.hannah.dto;

import lombok.Data;

@Data
public class ChuDeDTO {
    private Integer maChuDe;
    private String tenChuDe;
    private String moTa;
}