package com.hannah.dto;

import lombok.Data;

@Data
public class BaiKiemTraDTO {
    private Integer maBaiKiemTra;
    private String tenBaiKiemTra;
    private Integer maKhoaHoc;
    private Integer thuTu;
    private String capDo;
}