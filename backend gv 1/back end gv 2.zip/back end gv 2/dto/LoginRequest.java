package com.hannah.dto;

import lombok.Data;

@Data
public class LoginRequest {
    private String email;
    private String matKhau;
    private String hoTen;
}