package com.hannah.dto;

import lombok.Data;

@Data
public class HocVienDTO {
    private Integer maNguoiDung;
    private Integer maKhoaHoc;
    private String hoTen;
    private String email;
}