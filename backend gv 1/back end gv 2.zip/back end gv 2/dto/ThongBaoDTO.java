package com.hannah.dto;

import lombok.Data;

@Data
public class ThongBaoDTO {
    private Integer maThongBao;
    private String tieuDe;
    private String noiDung;
    private Integer maNguoiGui;
    private String doiTuongNhan;
}