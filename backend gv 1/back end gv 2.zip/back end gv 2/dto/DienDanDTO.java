package com.hannah.dto;

import lombok.Data;

@Data
public class DienDanDTO {
    private Integer maDienDan;
    private String tieuDe;
    private String noiDung;
    private Integer maNguoiDung;
    private Integer maKhoaHoc;
}