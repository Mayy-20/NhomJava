package com.hannah.dto;

import lombok.Data;

@Data
public class BaiDangDTO {
    private Integer maBaiDang;
    private String tieuDe;
    private String noiDung;
    private Integer maTacGia;
    private Integer maKhoaHoc;
}