package com.hannah.dto;

import lombok.Data;

@Data
public class TaiLieuDTO {
    private Integer maTaiLieu;
    private String tenTaiLieu;
    private String duongDan;
    private Integer maBaiHoc;
    private Integer maTacGia;
    private Integer maLoaiTaiLieu;
}