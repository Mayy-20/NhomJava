package com.hannah.dto;

import lombok.Data;

@Data
public class KhoaHocDTO {
    private Integer maKhoaHoc;
    private String tenKhoaHoc;
    private String moTa;
    private String hinhAnh;
    private Boolean mienPhi;
    private String trangThai;
    private Integer maGiangVien;
}