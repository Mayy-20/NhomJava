package com.hannah.dto;

import lombok.Data;

@Data
public class TienDoDTO {
    private Integer maTienDo;
    private Integer maNguoiDung;
    private Integer maKhoaHoc;
    private Integer maBaiHoc;
    private Integer phanTramHoanThanh;
}