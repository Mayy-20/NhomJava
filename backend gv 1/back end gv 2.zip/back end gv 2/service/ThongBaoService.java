package com.hannah.service;

import com.hannah.dto.ThongBaoDTO;
import com.hannah.entity.ThongBao;
import com.hannah.entity.NguoiDung;
import com.hannah.repository.ThongBaoRepository;
import com.hannah.repository.NguoiDungRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ThongBaoService {

    @Autowired
    private ThongBaoRepository thongBaoRepository;

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    public ThongBaoDTO createThongBao(ThongBaoDTO thongBaoDTO, Integer maNguoiGui) {
        NguoiDung nguoiGui = nguoiDungRepository.findById(maNguoiGui)
                .orElseThrow(() -> new RuntimeException("Người gửi không tồn tại"));
        ThongBao thongBao = new ThongBao();
        thongBao.setTieuDe(thongBaoDTO.getTieuDe());
        thongBao.setNoiDung(thongBaoDTO.getNoiDung());
        thongBao.setNguoiGui(nguoiGui);
        thongBao.setDoiTuongNhan(thongBaoDTO.getDoiTuongNhan());
        thongBao = thongBaoRepository.save(thongBao);
        return mapToDTO(thongBao);
    }

    public List<ThongBaoDTO> getThongBaoByNguoiGui(Integer maNguoiGui) {
        return thongBaoRepository.findByNguoiGuiMaNguoiDung(maNguoiGui)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public void deleteThongBao(Integer maThongBao) {
        ThongBao thongBao = thongBaoRepository.findById(maThongBao)
                .orElseThrow(() -> new RuntimeException("Thông báo không tồn tại"));
        thongBaoRepository.delete(thongBao);
    }

    private ThongBaoDTO mapToDTO(ThongBao thongBao) {
        ThongBaoDTO dto = new ThongBaoDTO();
        dto.setMaThongBao(thongBao.getMaThongBao());
        dto.setTieuDe(thongBao.getTieuDe());
        dto.setNoiDung(thongBao.getNoiDung());
        dto.setMaNguoiGui(thongBao.getNguoiGui().getMaNguoiDung());
        dto.setDoiTuongNhan(thongBao.getDoiTuongNhan());
        return dto;
    }
}