package com.hannah.service;

import com.hannah.dto.ChuDeDTO;
import com.hannah.entity.ChuDe;
import com.hannah.repository.ChuDeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ChuDeService {

    @Autowired
    private ChuDeRepository chuDeRepository;

    public ChuDeDTO createChuDe(ChuDeDTO chuDeDTO) {
        ChuDe chuDe = new ChuDe();
        chuDe.setTenChuDe(chuDeDTO.getTenChuDe());
        chuDe.setMoTa(chuDeDTO.getMoTa());
        chuDe = chuDeRepository.save(chuDe);
        return mapToDTO(chuDe);
    }

    public List<ChuDeDTO> getAllChuDe() {
        return chuDeRepository.findAll()
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public ChuDeDTO updateChuDe(Integer maChuDe, ChuDeDTO chuDeDTO) {
        ChuDe chuDe = chuDeRepository.findById(maChuDe)
                .orElseThrow(() -> new RuntimeException("Chủ đề không tồn tại"));
        chuDe.setTenChuDe(chuDeDTO.getTenChuDe());
        chuDe.setMoTa(chuDeDTO.getMoTa());
        chuDe = chuDeRepository.save(chuDe);
        return mapToDTO(chuDe);
    }

    public void deleteChuDe(Integer maChuDe) {
        ChuDe chuDe = chuDeRepository.findById(maChuDe)
                .orElseThrow(() -> new RuntimeException("Chủ đề không tồn tại"));
        chuDeRepository.delete(chuDe);
    }

    private ChuDeDTO mapToDTO(ChuDe chuDe) {
        ChuDeDTO dto = new ChuDeDTO();
        dto.setMaChuDe(chuDe.getMaChuDe());
        dto.setTenChuDe(chuDe.getTenChuDe());
        dto.setMoTa(chuDe.getMoTa());
        return dto;
    }
}