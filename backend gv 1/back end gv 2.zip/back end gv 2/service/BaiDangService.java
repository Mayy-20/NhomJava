package com.hannah.service;

import com.hannah.dto.BaiDangDTO;
import com.hannah.entity.BaiDang;
import com.hannah.entity.NguoiDung;
import com.hannah.entity.KhoaHoc;
import com.hannah.repository.BaiDangRepository;
import com.hannah.repository.NguoiDungRepository;
import com.hannah.repository.KhoaHocRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BaiDangService {

    @Autowired
    private BaiDangRepository baiDangRepository;

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    @Autowired
    private KhoaHocRepository khoaHocRepository;

    public BaiDangDTO createBaiDang(BaiDangDTO baiDangDTO, Integer maTacGia) {
        NguoiDung tacGia = nguoiDungRepository.findById(maTacGia)
                .orElseThrow(() -> new RuntimeException("Người dùng không tồn tại"));
        BaiDang baiDang = new BaiDang();
        baiDang.setTieuDe(baiDangDTO.getTieuDe());
        baiDang.setNoiDung(baiDangDTO.getNoiDung());
        baiDang.setTacGia(tacGia);
        if (baiDangDTO.getMaKhoaHoc() != null) {
            KhoaHoc khoaHoc = khoaHocRepository.findById(baiDangDTO.getMaKhoaHoc())
                    .orElseThrow(() -> new RuntimeException("Khóa học không tồn tại"));
            baiDang.setKhoaHoc(khoaHoc);
        }
        baiDang = baiDangRepository.save(baiDang);
        return mapToDTO(baiDang);
    }

    public List<BaiDangDTO> getAllBaiDang() {
        return baiDangRepository.findAll()
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public BaiDangDTO updateBaiDang(Integer maBaiDang, BaiDangDTO baiDangDTO) {
        BaiDang baiDang = baiDangRepository.findById(maBaiDang)
                .orElseThrow(() -> new RuntimeException("Bài đăng không tồn tại"));
        baiDang.setTieuDe(baiDangDTO.getTieuDe());
        baiDang.setNoiDung(baiDangDTO.getNoiDung());
        if (baiDangDTO.getMaKhoaHoc() != null) {
            KhoaHoc khoaHoc = khoaHocRepository.findById(baiDangDTO.getMaKhoaHoc())
                    .orElseThrow(() -> new RuntimeException("Khóa học không tồn tại"));
            baiDang.setKhoaHoc(khoaHoc);
        }
        baiDang = baiDangRepository.save(baiDang);
        return mapToDTO(baiDang);
    }

    public void deleteBaiDang(Integer maBaiDang) {
        BaiDang baiDang = baiDangRepository.findById(maBaiDang)
                .orElseThrow(() -> new RuntimeException("Bài đăng không tồn tại"));
        baiDangRepository.delete(baiDang);
    }

    private BaiDangDTO mapToDTO(BaiDang baiDang) {
        BaiDangDTO dto = new BaiDangDTO();
        dto.setMaBaiDang(baiDang.getMaBaiDang());
        dto.setTieuDe(baiDang.getTieuDe());
        dto.setNoiDung(baiDang.getNoiDung());
        dto.setMaTacGia(baiDang.getTacGia().getMaNguoiDung());
        dto.setMaKhoaHoc(baiDang.getKhoaHoc() != null ? baiDang.getKhoaHoc().getMaKhoaHoc() : null);
        return dto;
    }
}