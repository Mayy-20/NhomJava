package com.hannah.service;

import com.hannah.dto.TaiLieuDTO;
import com.hannah.entity.TaiLieu;
import com.hannah.entity.BaiHoc;
import com.hannah.entity.NguoiDung;
import com.hannah.entity.LoaiTaiLieu;
import com.hannah.repository.TaiLieuRepository;
import com.hannah.repository.BaiHocRepository;
import com.hannah.repository.NguoiDungRepository;
import com.hannah.repository.LoaiTaiLieuRepository;
import com.hannah.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaiLieuService {

    @Autowired
    private TaiLieuRepository taiLieuRepository;

    @Autowired
    private BaiHocRepository baiHocRepository;

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    @Autowired
    private LoaiTaiLieuRepository loaiTaiLieuRepository;

    @Autowired
    private FileUtil fileUtil;

    public TaiLieuDTO uploadTaiLieu(MultipartFile file, Integer maBaiHoc, Integer maTacGia) {
        BaiHoc baiHoc = baiHocRepository.findById(maBaiHoc)
                .orElseThrow(() -> new RuntimeException("Bài học không tồn tại"));
        NguoiDung tacGia = nguoiDungRepository.findById(maTacGia)
                .orElseThrow(() -> new RuntimeException("Người dùng không tồn tại"));
        String filePath = fileUtil.saveFile(file);
        LoaiTaiLieu loaiTaiLieu = loaiTaiLieuRepository.findByTenLoai(fileUtil.getFileExtension(file.getOriginalFilename()))
                .orElseGet(() -> {
                    LoaiTaiLieu newLoai = new LoaiTaiLieu();
                    newLoai.setTenLoai(fileUtil.getFileExtension(file.getOriginalFilename()));
                    return loaiTaiLieuRepository.save(newLoai);
                });
        TaiLieu taiLieu = new TaiLieu();
        taiLieu.setTenTaiLieu(file.getOriginalFilename());
        taiLieu.setDuongDan(filePath);
        taiLieu.setBaiHoc(baiHoc);
        taiLieu.setTacGia(tacGia);
        taiLieu.setLoaiTaiLieu(loaiTaiLieu);
        taiLieu = taiLieuRepository.save(taiLieu);
        return mapToDTO(taiLieu);
    }

    public List<TaiLieuDTO> getTaiLieuByBaiHoc(Integer maBaiHoc) {
        return taiLieuRepository.findByBaiHocMaBaiHoc(maBaiHoc)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public void deleteTaiLieu(Integer maTaiLieu) {
        TaiLieu taiLieu = taiLieuRepository.findById(maTaiLieu)
                .orElseThrow(() -> new RuntimeException("Tài liệu không tồn tại"));
        fileUtil.deleteFile(taiLieu.getDuongDan());
        taiLieuRepository.delete(taiLieu);
    }

    private TaiLieuDTO mapToDTO(TaiLieu taiLieu) {
        TaiLieuDTO dto = new TaiLieuDTO();
        dto.setMaTaiLieu(taiLieu.getMaTaiLieu());
        dto.setTenTaiLieu(taiLieu.getTenTaiLieu());
        dto.setDuongDan(taiLieu.getDuongDan());
        dto.setMaBaiHoc(taiLieu.getBaiHoc().getMaBaiHoc());
        dto.setMaTacGia(taiLieu.getTacGia().getMaNguoiDung());
        dto.setMaLoaiTaiLieu(taiLieu.getLoaiTaiLieu().getMaLoaiTaiLieu());
        return dto;
    }
}