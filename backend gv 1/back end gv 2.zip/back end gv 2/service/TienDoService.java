package com.hannah.service;

import com.hannah.dto.TienDoDTO;
import com.hannah.entity.TienDo;
import com.hannah.entity.NguoiDung;
import com.hannah.entity.KhoaHoc;
import com.hannah.repository.TienDoRepository;
import com.hannah.repository.NguoiDungRepository;
import com.hannah.repository.KhoaHocRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TienDoService {

    @Autowired
    private TienDoRepository tienDoRepository;

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    @Autowired
    private KhoaHocRepository khoaHocRepository;

    public List<TienDoDTO> getTienDoByHocVien(Integer maNguoiDung) {
        return tienDoRepository.findByHocVienMaNguoiDung(maNguoiDung)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public TienDoDTO getTienDoByHocVienAndKhoaHoc(Integer maNguoiDung, Integer maKhoaHoc) {
        TienDo tienDo = tienDoRepository.findByHocVienMaNguoiDungAndKhoaHocMaKhoaHoc(maNguoiDung, maKhoaHoc);
        if (tienDo == null) {
            throw new RuntimeException("Tiến độ không tồn tại");
        }
        return mapToDTO(tienDo);
    }

    public TienDoDTO updateTienDo(Integer maTienDo, TienDoDTO tienDoDTO) {
        TienDo tienDo = tienDoRepository.findById(maTienDo)
                .orElseThrow(() -> new RuntimeException("Tiến độ không tồn tại"));
        tienDo.setPhanTramHoanThanh(tienDoDTO.getPhanTramHoanThanh());
        if (tienDoDTO.getMaBaiHoc() != null) {
            BaiHoc baiHoc = baiHocRepository.findById(tienDoDTO.getMaBaiHoc())
                    .orElseThrow(() -> new RuntimeException("Bài học không tồn tại"));
            tienDo.setBaiHoc(baiHoc);
        }
        tienDo = tienDoRepository.save(tienDo);
        return mapToDTO(tienDo);
    }

    private TienDoDTO mapToDTO(TienDo tienDo) {
        TienDoDTO dto = new TienDoDTO();
        dto.setMaTienDo(tienDo.getMaTienDo());
        dto.setMaNguoiDung(tienDo.getHocVien().getMaNguoiDung());
        dto.setMaKhoaHoc(tienDo.getKhoaHoc().getMaKhoaHoc());
        dto.setMaBaiHoc(tienDo.getBaiHoc() != null ? tienDo.getBaiHoc().getMaBaiHoc() : null);
        dto.setPhanTramHoanThanh(tienDo.getPhanTramHoanThanh());
        return dto;
    }
}