package com.hannah.service;

import com.hannah.dto.BaiKiemTraDTO;
import com.hannah.entity.BaiHoc;
import com.hannah.repository.BaiHocRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BaiKiemTraService {

    @Autowired
    private BaiHocRepository baiHocRepository;

    public BaiKiemTraDTO createBaiKiemTra(BaiKiemTraDTO baiKiemTraDTO, Integer maKhoaHoc) {
        BaiHoc baiHoc = new BaiHoc();
        baiHoc.setTenBaiHoc(baiKiemTraDTO.getTenBaiKiemTra());
        baiHoc.setKhoaHoc(khoaHocRepository.findById(maKhoaHoc)
                .orElseThrow(() -> new RuntimeException("Khóa học không tồn tại")));
        baiHoc.setThuTu(baiKiemTraDTO.getThuTu());
        baiHoc.setCapDo(BaiHoc.CapDo.valueOf(baiKiemTraDTO.getCapDo()));
        baiHoc = baiHocRepository.save(baiHoc);
        return mapToDTO(baiHoc);
    }

    public List<BaiKiemTraDTO> getBaiKiemTraByKhoaHoc(Integer maKhoaHoc) {
        return baiHocRepository.findByKhoaHocMaKhoaHoc(maKhoaHoc)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public BaiKiemTraDTO updateBaiKiemTra(Integer maBaiKiemTra, BaiKiemTraDTO baiKiemTraDTO) {
        BaiHoc baiHoc = baiHocRepository.findById(maBaiKiemTra)
                .orElseThrow(() -> new RuntimeException("Bài kiểm tra không tồn tại"));
        baiHoc.setTenBaiHoc(baiKiemTraDTO.getTenBaiKiemTra());
        baiHoc.setThuTu(baiKiemTraDTO.getThuTu());
        baiHoc.setCapDo(BaiHoc.CapDo.valueOf(baiKiemTraDTO.getCapDo()));
        baiHoc = baiHocRepository.save(baiHoc);
        return mapToDTO(baiHoc);
    }

    public void deleteBaiKiemTra(Integer maBaiKiemTra) {
        BaiHoc baiHoc = baiHocRepository.findById(maBaiKiemTra)
                .orElseThrow(() -> new RuntimeException("Bài kiểm tra không tồn tại"));
        baiHocRepository.delete(baiHoc);
    }

    private BaiKiemTraDTO mapToDTO(BaiHoc baiHoc) {
        BaiKiemTraDTO dto = new BaiKiemTraDTO();
        dto.setMaBaiKiemTra(baiHoc.getMaBaiHoc());
        dto.setTenBaiKiemTra(baiHoc.getTenBaiHoc());
        dto.setMaKhoaHoc(baiHoc.getKhoaHoc().getMaKhoaHoc());
        dto.setThuTu(baiHoc.getThuTu());
        dto.setCapDo(baiHoc.getCapDo().name());
        return dto;
    }
}