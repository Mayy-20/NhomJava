package com.hannah.service;

import com.hannah.dto.BinhLuanDTO;
import com.hannah.entity.BinhLuan;
import com.hannah.entity.BaiDang;
import com.hannah.entity.NguoiDung;
import com.hannah.repository.BinhLuanRepository;
import com.hannah.repository.BaiDangRepository;
import com.hannah.repository.NguoiDungRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BinhLuanService {

    @Autowired
    private BinhLuanRepository binhLuanRepository;

    @Autowired
    private BaiDangRepository baiDangRepository;

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    public BinhLuanDTO createBinhLuan(BinhLuanDTO binhLuanDTO, Integer maBaiDang, Integer maNguoiDung) {
        BaiDang baiDang = baiDangRepository.findById(maBaiDang)
                .orElseThrow(() -> new RuntimeException("Bài đăng không tồn tại"));
        NguoiDung nguoiDung = nguoiDungRepository.findById(maNguoiDung)
                .orElseThrow(() -> new RuntimeException("Người dùng không tồn tại"));
        BinhLuan binhLuan = new BinhLuan();
        binhLuan.setNoiDung(binhLuanDTO.getNoiDung());
        binhLuan.setBaiDang(baiDang);
        binhLuan.setNguoiDung(nguoiDung);
        binhLuan = binhLuanRepository.save(binhLuan);
        return mapToDTO(binhLuan);
    }

    public List<BinhLuanDTO> getBinhLuanByBaiDang(Integer maBaiDang) {
        return binhLuanRepository.findByBaiDangMaBaiDang(maBaiDang)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public void deleteBinhLuan(Integer maBinhLuan) {
        BinhLuan binhLuan = binhLuanRepository.findById(maBinhLuan)
                .orElseThrow(() -> new RuntimeException("Bình luận không tồn tại"));
        binhLuanRepository.delete(binhLuan);
    }

    private BinhLuanDTO mapToDTO(BinhLuan binhLuan) {
        BinhLuanDTO dto = new BinhLuanDTO();
        dto.setMaBinhLuan(binhLuan.getMaBinhLuan());
        dto.setNoiDung(binhLuan.getNoiDung());
        dto.setMaBaiDang(binhLuan.getBaiDang().getMaBaiDang());
        dto.setMaNguoiDung(binhLuan.getNguoiDung().getMaNguoiDung());
        return dto;
    }
}