package com.hannah.service;

import com.hannah.dto.DienDanDTO;
import com.hannah.entity.BaiDang;
import com.hannah.entity.NguoiDung;
import com.hannah.entity.KhoaHoc;
import com.hannah.repository.BaiDangRepository;
import com.hannah.repository.NguoiDungRepository;
import com.hannah.repository.KhoaHocRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DienDanService {

    @Autowired
    private BaiDangRepository baiDangRepository;

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    @Autowired
    private KhoaHocRepository khoaHocRepository;

    public DienDanDTO createDienDanPost(DienDanDTO dienDanDTO, Integer maNguoiDung) {
        NguoiDung nguoiDung = nguoiDungRepository.findById(maNguoiDung)
                .orElseThrow(() -> new RuntimeException("Người dùng không tồn tại"));
        KhoaHoc khoaHoc = khoaHocRepository.findById(dienDanDTO.getMaKhoaHoc())
                .orElseThrow(() -> new RuntimeException("Khóa học không tồn tại"));
        BaiDang baiDang = new BaiDang();
        baiDang.setTieuDe(dienDanDTO.getTieuDe());
        baiDang.setNoiDung(dienDanDTO.getNoiDung());
        baiDang.setTacGia(nguoiDung);
        baiDang.setKhoaHoc(khoaHoc);
        baiDang = baiDangRepository.save(baiDang);
        return mapToDTO(baiDang);
    }

    public List<DienDanDTO> getDienDanByKhoaHoc(Integer maKhoaHoc) {
        return baiDangRepository.findByKhoaHocMaKhoaHoc(maKhoaHoc)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public void deleteDienDanPost(Integer maDienDan) {
        BaiDang baiDang = baiDangRepository.findById(maDienDan)
                .orElseThrow(() -> new RuntimeException("Bài đăng không tồn tại"));
        baiDangRepository.delete(baiDang);
    }

    private DienDanDTO mapToDTO(BaiDang baiDang) {
        DienDanDTO dto = new DienDanDTO();
        dto.setMaDienDan(baiDang.getMaBaiDang());
        dto.setTieuDe(baiDang.getTieuDe());
        dto.setNoiDung(baiDang.getNoiDung());
        dto.setMaNguoiDung(baiDang.getTacGia().getMaNguoiDung());
        dto.setMaKhoaHoc(baiDang.getKhoaHoc().getMaKhoaHoc());
        return dto;
    }
}