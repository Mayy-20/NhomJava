package com.hannah.service;

import com.hannah.dto.KhoaHocDTO;
import com.hannah.entity.KhoaHoc;
import com.hannah.entity.NguoiDung;
import com.hannah.repository.KhoaHocRepository;
import com.hannah.repository.NguoiDungRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class KhoaHocService {

    @Autowired
    private KhoaHocRepository khoaHocRepository;

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    public KhoaHocDTO createKhoaHoc(KhoaHocDTO khoaHocDTO, Integer maGiangVien) {
        NguoiDung giangVien = nguoiDungRepository.findById(maGiangVien)
                .orElseThrow(() -> new RuntimeException("Giảng viên không tồn tại"));
        KhoaHoc khoaHoc = new KhoaHoc();
        khoaHoc.setTenKhoaHoc(khoaHocDTO.getTenKhoaHoc());
        khoaHoc.setMoTa(khoaHocDTO.getMoTa());
        khoaHoc.setHinhAnh(khoaHocDTO.getHinhAnh());
        khoaHoc.setMienPhi(khoaHocDTO.getMienPhi());
        khoaHoc.setTrangThai(KhoaHoc.TrangThaiKhoaHoc.ChoDuyet);
        khoaHoc.setGiangVien(giangVien);
        khoaHoc = khoaHocRepository.save(khoaHoc);
        return mapToDTO(khoaHoc);
    }

    public List<KhoaHocDTO> getKhoaHocByGiangVien(Integer maGiangVien) {
        return khoaHocRepository.findByGiangVienMaNguoiDung(maGiangVien)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public KhoaHocDTO getKhoaHocById(Integer maKhoaHoc) {
        KhoaHoc khoaHoc = khoaHocRepository.findById(maKhoaHoc)
                .orElseThrow(() -> new RuntimeException("Khóa học không tồn tại"));
        return mapToDTO(khoaHoc);
    }

    public KhoaHocDTO updateKhoaHoc(Integer maKhoaHoc, KhoaHocDTO khoaHocDTO) {
        KhoaHoc khoaHoc = khoaHocRepository.findById(maKhoaHoc)
                .orElseThrow(() -> new RuntimeException("Khóa học không tồn tại"));
        khoaHoc.setTenKhoaHoc(khoaHocDTO.getTenKhoaHoc());
        khoaHoc.setMoTa(khoaHocDTO.getMoTa());
        khoaHoc.setHinhAnh(khoaHocDTO.getHinhAnh());
        khoaHoc.setMienPhi(khoaHocDTO.getMienPhi());
        khoaHoc.setTrangThai(KhoaHoc.TrangThaiKhoaHoc.valueOf(khoaHocDTO.getTrangThai()));
        khoaHoc = khoaHocRepository.save(khoaHoc);
        return mapToDTO(khoaHoc);
    }

    public void deleteKhoaHoc(Integer maKhoaHoc) {
        KhoaHoc khoaHoc = khoaHocRepository.findById(maKhoaHoc)
                .orElseThrow(() -> new RuntimeException("Khóa học không tồn tại"));
        khoaHocRepository.delete(khoaHoc);
    }

    private KhoaHocDTO mapToDTO(KhoaHoc khoaHoc) {
        KhoaHocDTO dto = new KhoaHocDTO();
        dto.setMaKhoaHoc(khoaHoc.getMaKhoaHoc());
        dto.setTenKhoaHoc(khoaHoc.getTenKhoaHoc());
        dto.setMoTa(khoaHoc.getMoTa());
        dto.setHinhAnh(khoaHoc.getHinhAnh());
        dto.setMienPhi(khoaHoc.getMienPhi());
        dto.setTrangThai(khoaHoc.getTrangThai().name());
        dto.setMaGiangVien(khoaHoc.getGiangVien().getMaNguoiDung());
        return dto;
    }
}