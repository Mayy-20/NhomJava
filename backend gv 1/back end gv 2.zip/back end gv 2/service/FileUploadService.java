package com.hannah.service;

import com.hannah.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileUploadService {

    @Autowired
    private FileUtil fileUtil;

    public String uploadFile(MultipartFile file) {
        return fileUtil.saveFile(file);
    }

    public void deleteFile(String filePath) {
        fileUtil.deleteFile(filePath);
    }
}