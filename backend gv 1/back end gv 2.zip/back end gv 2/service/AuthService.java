package com.hannah.service;

import com.hannah.dto.LoginRequest;
import com.hannah.dto.LoginResponse;
import com.hannah.entity.NguoiDung;
import com.hannah.entity.VaiTro;
import com.hannah.repository.NguoiDungRepository;
import com.hannah.repository.VaiTroRepository;
import com.hannah.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    @Autowired
    private VaiTroRepository vaiTroRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public LoginResponse login(String email, String matKhau) {
        NguoiDung nguoiDung = nguoiDungRepository.findByEmail(email);
        if (nguoiDung == null || !passwordEncoder.matches(matKhau, nguoiDung.getMatKhau())) {
            throw new RuntimeException("Invalid email or password");
        }
        String token = jwtUtil.generateToken(nguoiDung.getEmail(), nguoiDung.getVaiTro().getTenVaiTro());
        return new LoginResponse(nguoiDung.getMaNguoiDung(), nguoiDung.getEmail(), nguoiDung.getHoTen(), token);
    }

    public LoginResponse register(String email, String matKhau, String hoTen) {
        if (nguoiDungRepository.findByEmail(email) != null) {
            throw new RuntimeException("Email already exists");
        }
        NguoiDung nguoiDung = new NguoiDung();
        nguoiDung.setEmail(email);
        nguoiDung.setMatKhau(passwordEncoder.encode(matKhau));
        nguoiDung.setHoTen(hoTen);
        nguoiDung.setTrangThai(NguoiDung.TrangThaiNguoiDung.Active);
        VaiTro vaiTro = vaiTroRepository.findByTenVaiTro("HOCVIEN");
        if (vaiTro == null) {
            vaiTro = new VaiTro();
            vaiTro.setTenVaiTro("HOCVIEN");
            vaiTro = vaiTroRepository.save(vaiTro);
        }
        nguoiDung.setVaiTro(vaiTro);
        nguoiDung = nguoiDungRepository.save(nguoiDung);
        String token = jwtUtil.generateToken(nguoiDung.getEmail(), nguoiDung.getVaiTro().getTenVaiTro());
        return new LoginResponse(nguoiDung.getMaNguoiDung(), nguoiDung.getEmail(), nguoiDung.getHoTen(), token);
    }
}