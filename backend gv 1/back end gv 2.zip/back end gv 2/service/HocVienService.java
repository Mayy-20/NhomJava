package com.hannah.service;

import com.hannah.dto.HocVienDTO;
import com.hannah.entity.DangKy;
import com.hannah.entity.NguoiDung;
import com.hannah.entity.KhoaHoc;
import com.hannah.repository.DangKyRepository;
import com.hannah.repository.NguoiDungRepository;
import com.hannah.repository.KhoaHocRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class HocVienService {

    @Autowired
    private DangKyRepository dangKyRepository;

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    @Autowired
    private KhoaHocRepository khoaHocRepository;

    public HocVienDTO addHocVien(HocVienDTO hocVienDTO) {
        NguoiDung hocVien = nguoiDungRepository.findById(hocVienDTO.getMaNguoiDung())
                .orElseThrow(() -> new RuntimeException("Người dùng không tồn tại"));
        KhoaHoc khoaHoc = khoaHocRepository.findById(hocVienDTO.getMaKhoaHoc())
                .orElseThrow(() -> new RuntimeException("Khóa học không tồn tại"));
        DangKy dangKy = new DangKy();
        dangKy.setHocVien(hocVien);
        dangKy.setKhoaHoc(khoaHoc);
        dangKy = dangKyRepository.save(dangKy);
        return mapToDTO(dangKy);
    }

    public List<HocVienDTO> getHocVienByKhoaHoc(Integer maKhoaHoc) {
        return dangKyRepository.findByKhoaHocMaKhoaHoc(maKhoaHoc)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public HocVienDTO getHocVienById(Integer maNguoiDung) {
        NguoiDung hocVien = nguoiDungRepository.findById(maNguoiDung)
                .orElseThrow(() -> new RuntimeException("Học viên không tồn tại"));
        return mapToDTO(hocVien);
    }

    public void deleteHocVien(Integer maNguoiDung) {
        List<DangKy> dangKys = dangKyRepository.findByHocVienMaNguoiDung(maNguoiDung);
        dangKyRepository.deleteAll(dangKys);
    }

    private HocVienDTO mapToDTO(DangKy dangKy) {
        HocVienDTO dto = new HocVienDTO();
        dto.setMaNguoiDung(dangKy.getHocVien().getMaNguoiDung());
        dto.setMaKhoaHoc(dangKy.getKhoaHoc().getMaKhoaHoc());
        return dto;
    }

    private HocVienDTO mapToDTO(NguoiDung hocVien) {
        HocVienDTO dto = new HocVienDTO();
        dto.setMaNguoiDung(hocVien.getMaNguoiDung());
        dto.setHoTen(hocVien.getHoTen());
        dto.setEmail(hocVien.getEmail());
        return dto;
    }
}