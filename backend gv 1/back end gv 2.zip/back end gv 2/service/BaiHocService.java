package com.hannah.service;

import com.hannah.dto.BaiHocDTO;
import com.hannah.entity.BaiHoc;
import com.hannah.entity.KhoaHoc;
import com.hannah.repository.BaiHocRepository;
import com.hannah.repository.KhoaHocRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BaiHocService {

    @Autowired
    private BaiHocRepository baiHocRepository;

    @Autowired
    private KhoaHocRepository khoaHocRepository;

    public BaiHocDTO createBaiHoc(BaiHocDTO baiHocDTO, Integer maKhoaHoc) {
        KhoaHoc khoaHoc = khoaHocRepository.findById(maKhoaHoc)
                .orElseThrow(() -> new RuntimeException("Khóa học không tồn tại"));
        BaiHoc baiHoc = new BaiHoc();
        baiHoc.setTenBaiHoc(baiHocDTO.getTenBaiHoc());
        baiHoc.setKhoaHoc(khoaHoc);
        baiHoc.setThuTu(baiHocDTO.getThuTu());
        baiHoc.setVideoURL(baiHocDTO.getVideoURL());
        baiHoc.setCapDo(BaiHoc.CapDo.valueOf(baiHocDTO.getCapDo()));
        baiHoc.setThoiLuong(baiHocDTO.getThoiLuong());
        baiHoc = baiHocRepository.save(baiHoc);
        return mapToDTO(baiHoc);
    }

    public List<BaiHocDTO> getBaiHocByKhoaHoc(Integer maKhoaHoc) {
        return baiHocRepository.findByKhoaHocMaKhoaHoc(maKhoaHoc)
                .stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    public BaiHocDTO updateBaiHoc(Integer maBaiHoc, BaiHocDTO baiHocDTO) {
        BaiHoc baiHoc = baiHocRepository.findById(maBaiHoc)
                .orElseThrow(() -> new RuntimeException("Bài học không tồn tại"));
        baiHoc.setTenBaiHoc(baiHocDTO.getTenBaiHoc());
        baiHoc.setThuTu(baiHocDTO.getThuTu());
        baiHoc.setVideoURL(baiHocDTO.getVideoURL());
        baiHoc.setCapDo(BaiHoc.CapDo.valueOf(baiHocDTO.getCapDo()));
        baiHoc.setThoiLuong(baiHocDTO.getThoiLuong());
        baiHoc = baiHocRepository.save(baiHoc);
        return mapToDTO(baiHoc);
    }

    public void deleteBaiHoc(Integer maBaiHoc) {
        BaiHoc baiHoc = baiHocRepository.findById(maBaiHoc)
                .orElseThrow(() -> new RuntimeException("Bài học không tồn tại"));
        baiHocRepository.delete(baiHoc);
    }

    private BaiHocDTO mapToDTO(BaiHoc baiHoc) {
        BaiHocDTO dto = new BaiHocDTO();
        dto.setMaBaiHoc(baiHoc.getMaBaiHoc());
        dto.setTenBaiHoc(baiHoc.getTenBaiHoc());
        dto.setMaKhoaHoc(baiHoc.getKhoaHoc().getMaKhoaHoc());
        dto.setThuTu(baiHoc.getThuTu());
        dto.setVideoURL(baiHoc.getVideoURL());
        dto.setCapDo(baiHoc.getCapDo().name());
        dto.setThoiLuong(baiHoc.getThoiLuong());
        return dto;
    }
}