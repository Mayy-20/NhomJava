package com.hannah.service;

import com.hannah.dto.NguoiDungDTO;
import com.hannah.entity.NguoiDung;
import com.hannah.repository.NguoiDungRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NguoiDungService {

    @Autowired
    private NguoiDungRepository nguoiDungRepository;

    public NguoiDungDTO getNguoiDungById(Integer maNguoiDung) {
        NguoiDung nguoiDung = nguoiDungRepository.findById(maNguoiDung)
                .orElseThrow(() -> new RuntimeException("Người dùng không tồn tại"));
        return mapToDTO(nguoiDung);
    }

    public NguoiDungDTO updateNguoiDung(Integer maNguoiDung, NguoiDungDTO nguoiDungDTO) {
        NguoiDung nguoiDung = nguoiDungRepository.findById(maNguoiDung)
                .orElseThrow(() -> new RuntimeException("Người dùng không tồn tại"));
        nguoiDung.setHoTen(nguoiDungDTO.getHoTen());
        nguoiDung.setDienThoai(nguoiDungDTO.getDienThoai());
        nguoiDung.setGioiThieu(nguoiDungDTO.getGioiThieu());
        nguoiDung.setAnhDaiDien(nguoiDungDTO.getAnhDaiDien());
        nguoiDung = nguoiDungRepository.save(nguoiDung);
        return mapToDTO(nguoiDung);
    }

    public NguoiDungDTO updateSettings(Integer maNguoiDung, NguoiDungDTO settingsDTO) {
        NguoiDung nguoiDung = nguoiDungRepository.findById(maNguoiDung)
                .orElseThrow(() -> new RuntimeException("Người dùng không tồn tại"));
        if (settingsDTO.getMatKhau() != null) {
            nguoiDung.setMatKhau(new BCryptPasswordEncoder().encode(settingsDTO.getMatKhau()));
        }
        nguoiDung = nguoiDungRepository.save(nguoiDung);
        return mapToDTO(nguoiDung);
    }

    private NguoiDungDTO mapToDTO(NguoiDung nguoiDung) {
        NguoiDungDTO dto = new NguoiDungDTO();
        dto.setMaNguoiDung(nguoiDung.getMaNguoiDung());
        dto.setTenDangNhap(nguoiDung.getTenDangNhap());
        dto.setEmail(nguoiDung.getEmail());
        dto.setHoTen(nguoiDung.getHoTen());
        dto.setDienThoai(nguoiDung.getDienThoai());
        dto.setGioiThieu(nguoiDung.getGioiThieu());
        dto.setAnhDaiDien(nguoiDung.getAnhDaiDien());
        dto.setTrangThai(nguoiDung.getTrangThai().name());
        return dto;
    }
}