package com.hannah.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.beans.factory.annotation.Autowired;
import com.hannah.util.JwtUtil;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private JwtUtil jwtUtil;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/api/khoahoc/**").hasAnyRole("GIANGVIEN", "ADMIN")
                .requestMatchers("/api/hocvien/**").hasAnyRole("GIANGVIEN", "ADMIN")
                .requestMatchers("/api/thongbao/**").hasAnyRole("GIANGVIEN", "ADMIN")
                .requestMatchers("/api/baidang/**").hasAnyRole("GIANGVIEN", "HOCVIEN", "ADMIN")
                .requestMatchers("/api/diendan/**").hasAnyRole("GIANGVIEN", "HOCVIEN", "ADMIN")
                .requestMatchers("/api/baikiemtra/**").hasAnyRole("GIANGVIEN", "ADMIN")
                .requestMatchers("/api/tiendo/**").hasAnyRole("GIANGVIEN", "HOCVIEN", "ADMIN")
                .requestMatchers("/api/nguoidung/**").hasAnyRole("GIANGVIEN", "HOCVIEN", "ADMIN")
                .anyRequest().authenticated()
            )
            .addFilterBefore(new JwtAuthenticationFilter(jwtUtil), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}