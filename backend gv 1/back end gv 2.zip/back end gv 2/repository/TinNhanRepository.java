package com.hannah.repository;

import com.hannah.entity.TinNhan;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TinNhanRepository extends JpaRepository<TinNhan, Integer> {
    List<TinNhan> findByPhienChatMaPhienChat(Integer maPhienChat);
}