package com.hannah.repository;

import com.hannah.entity.TaiLieu;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TaiLieuRepository extends JpaRepository<TaiLieu, Integer> {
    List<TaiLieu> findByBaiHocMaBaiHoc(Integer maBaiHoc);
}