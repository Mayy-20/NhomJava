package com.hannah.repository;

import com.hannah.entity.LoaiTaiLieu;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoaiTaiLieuRepository extends JpaRepository<LoaiTaiLieu, Integer> {
    LoaiTaiLieu findByTenLoai(String tenLoai);
}