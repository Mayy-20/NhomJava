package com.hannah.repository;

import com.hannah.entity.PhienChat;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PhienChatRepository extends JpaRepository<PhienChat, Integer> {
    List<PhienChat> findByNguoiDungMaNguoiDung(Integer maNguoiDung);
}