package com.hannah.repository;

import com.hannah.entity.TienDo;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TienDoRepository extends JpaRepository<TienDo, Integer> {
    List<TienDo> findByHocVienMaNguoiDung(Integer maNguoiDung);
    TienDo findByHocVienMaNguoiDungAndKhoaHocMaKhoaHoc(Integer maNguoiDung, Integer maKhoaHoc);
}