package com.hannah.repository;

import com.hannah.entity.BaiDang;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BaiDangRepository extends JpaRepository<BaiDang, Integer> {
    List<BaiDang> findByTacGiaMaNguoiDung(Integer maTacGia);
    List<BaiDang> findByKhoaHocMaKhoaHoc(Integer maKhoaHoc);
}