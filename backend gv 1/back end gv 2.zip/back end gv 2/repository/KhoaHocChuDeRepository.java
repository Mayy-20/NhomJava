package com.hannah.repository;

import com.hannah.entity.KhoaHocChuDe;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface KhoaHocChuDeRepository extends JpaRepository<KhoaHocChuDe, Integer> {
    List<KhoaHocChuDe> findByKhoaHocMaKhoaHoc(Integer maKhoaHoc);
    List<KhoaHocChuDe> findByChuDeMaChuDe(Integer maChuDe);
}