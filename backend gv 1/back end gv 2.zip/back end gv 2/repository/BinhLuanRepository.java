package com.hannah.repository;

import com.hannah.entity.BinhLuan;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BinhLuanRepository extends JpaRepository<BinhLuan, Integer> {
    List<BinhLuan> findByBaiDangMaBaiDang(Integer maBaiDang);
}