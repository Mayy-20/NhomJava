package com.hannah.repository;

import com.hannah.entity.ChuDe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChuDeRepository extends JpaRepository<ChuDe, Integer> {
    ChuDe findByTenChuDe(String tenChuDe);
}