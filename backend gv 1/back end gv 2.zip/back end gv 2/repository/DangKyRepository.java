package com.hannah.repository;

import com.hannah.entity.DangKy;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DangKyRepository extends JpaRepository<DangKy, Integer> {
    List<DangKy> findByHocVienMaNguoiDung(Integer maNguoiDung);
    List<DangKy> findByKhoaHocMaKhoaHoc(Integer maKhoaHoc);
}