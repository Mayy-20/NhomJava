package com.hannah.repository;

import com.hannah.entity.NguoiDung;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NguoiDungRepository extends JpaRepository<NguoiDung, Integer> {
    NguoiDung findByEmail(String email);
    NguoiDung findByTenDangNhap(String tenDangNhap);
}