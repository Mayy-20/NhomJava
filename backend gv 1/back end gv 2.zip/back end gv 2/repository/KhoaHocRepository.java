package com.hannah.repository;

import com.hannah.entity.KhoaHoc;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface KhoaHocRepository extends JpaRepository<KhoaHoc, Integer> {
    List<KhoaHoc> findByGiangVienMaNguoiDung(Integer maGiangVien);
    List<KhoaHoc> findByTrangThai(KhoaHoc.TrangThaiKhoaHoc trangThai);
}