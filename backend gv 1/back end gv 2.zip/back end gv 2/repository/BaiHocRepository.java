package com.hannah.repository;

import com.hannah.entity.BaiHoc;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BaiHocRepository extends JpaRepository<BaiHoc, Integer> {
    List<BaiHoc> findByKhoaHocMaKhoaHoc(Integer maKhoaHoc);
}