package com.hannah.util;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class RestResponse<T> {
    private LocalDateTime timestamp;
    private String message;
    private String path;
    private T data;
    private int status;

    public RestResponse(int status, String message, T data, String path) {
        this.timestamp = LocalDateTime.now();
        this.message = message;
        this.data = data;
        this.path = path;
        this.status = status;
    }

    public static <T> RestResponse<T> success(T data, String path) {
        return new RestResponse<>(200, "Success", data, path);
    }

    public static <T> RestResponse<T> error(int status, String message, String path) {
        return new RestResponse<>(status, message, null, path);
    }
}